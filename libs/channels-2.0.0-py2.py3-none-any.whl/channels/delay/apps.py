from django.apps import AppConfig


class DelayConfig(AppConfig):

    name = "channels.delay"
    label = "channels.delay"
    verbose_name = "Channels Delay"
