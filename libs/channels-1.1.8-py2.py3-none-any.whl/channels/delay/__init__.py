default_app_config = 'channels.delay.apps.DelayConfig'
