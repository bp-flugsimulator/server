# utils für bp-flugsimulator/server und bp-flugsimulator/client

[![Updates](https://pyup.io/repos/github/bp-flugsimulator/utils/shield.svg)](https://pyup.io/repos/github/bp-flugsimulator/utils/)
[![Build Status](https://travis-ci.org/bp-flugsimulator/utils.svg?branch=master)](https://travis-ci.org/bp-flugsimulator/utils)
[![Coverage Status](https://coveralls.io/repos/github/bp-flugsimulator/utils/badge.svg)](https://coveralls.io/github/bp-flugsimulator/utils)
[![AppVeyor Status](https://ci.appveyor.com/api/projects/status/32r7s2skrgm9ubva?svg=true)](https://ci.appveyor.com/project/GreenM0nst3r/utils)

Enthält utils die für den Client und den Server gebraucht werden
