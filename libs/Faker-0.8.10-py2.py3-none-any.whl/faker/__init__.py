VERSION = '0.8.10'

from faker.generator import Generator
from faker.factory import Factory

Faker = Factory.create
